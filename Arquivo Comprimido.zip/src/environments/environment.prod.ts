export const environment = {
    production: true,
    apiUrl: 'https://crtcc.herokuapp.com/'
};
