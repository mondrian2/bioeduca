import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-avaliacao',
  templateUrl: './avaliacao.component.html',
  styleUrls: ['./avaliacao.component.less']
})
export class AvaliacaoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
