import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aceite',
  templateUrl: './aceite.component.html',
  styleUrls: ['./aceite.component.less']
})
export class AceiteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
