﻿export class User {
    id: number;
    nome: string;
    ocupacao: string;
    sexo:string;
    token: string;
    username:string;
    password:string;
}